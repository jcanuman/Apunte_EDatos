        #include "tree.h"
        #include <stdlib.h>
        #include "fatal.h"

        typedef  SearchTree ElementTypeN;
        typedef struct Node *PtrToNode;
        typedef PtrToNode Stack;

        struct TreeNode
        {
            ElementType Element;
            SearchTree  Left;
            SearchTree  Right;
        };

        struct Node
        {
            ElementTypeN Element;
            PtrToNode   Next;
        };

        int IsEmptyS( Stack S );
        Stack CreateStack( void );
        void MakeEmptyS( Stack S );
        void Push( ElementTypeN X, Stack S );
        ElementTypeN Top( Stack S );
        void Pop( Stack S );
        void PreOrderS(SearchTree T, void (*func)(ElementType ) );

        int
        IsEmptyS( Stack S )
        {
            return S->Next == NULL;
        }

        Stack
        CreateStack( void )
        {
            Stack S;

            S = malloc( sizeof( struct Node ) );
            if( S == NULL )
                FatalError( "Out of space!!!" );
            S->Next = NULL;
            MakeEmptyS( S );
            return S;
        }

        void
        MakeEmptyS( Stack S )
        {
            if( S == NULL )
                Error( "Must use CreateStack first" );
            else
                while( !IsEmptyS( S ) )
                    Pop( S );
        }

        void
        Push( ElementTypeN X, Stack S )
        {
            PtrToNode TmpCell;

            TmpCell = malloc( sizeof( struct Node ) );
            if( TmpCell == NULL )
                FatalError( "Out of space!!!" );
            else
            {
                TmpCell->Element = X;
                TmpCell->Next = S->Next;
                S->Next = TmpCell;
            }
        }

        ElementTypeN
        Top( Stack S )
        {
            if( !IsEmptyS( S ) )
                return S->Next->Element;
            Error( "Empty stack" );
        }

        void
        Pop( Stack S )
        {
            PtrToNode FirstCell;

            if( IsEmptyS( S ) )
                Error( "Empty stack" );
            else
            {
                FirstCell = S->Next;
                S->Next = S->Next->Next;
                free( FirstCell );
            }
        }
/* START: fig6_m1.txt */
void PreOrderS(SearchTree T, void (*func)(ElementType ))
{
  SearchTree TmpCell;
  Stack S = CreateStack( );

  Push( T, S );
  while( !IsEmptyS( S ) ) 
  {
    TmpCell = Top( S ); Pop( S );
    if (TmpCell != NULL )
    {
      func(TmpCell->Element);
      Push( TmpCell->Right, S );
      Push( TmpCell->Left, S );
    }
  }
}
/* END */ 

/* START: fig6_m2.txt */
void PreOrderSV2(SearchTree T, void (*func)(ElementType ))
{
  SearchTree TmpCell;
  Stack S = CreateStack( );

  Push( T, S );
  while( !IsEmptyS( S ) ) 
  {
    TmpCell = Top( S ); Pop( S );
    while (TmpCell != NULL )
    {
      func(TmpCell->Element);
      Push( TmpCell->Right, S );
      TmpCell = TmpCell->Left ;
    }
  }
}
/* END */ 

