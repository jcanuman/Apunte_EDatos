#include "tree.h"
#include <stdio.h>

void PrintElement( ElementType E )
{
    printf("%d ",E);
}

main( )
{
    SearchTree T;
    Position P;
    int i;
    int j = 0;

    T = MakeEmpty( NULL ); 
    printf( "    Input: ");
    for( i = 0; i < 10; i++, j = ( j + 7 ) % 10 ){
        PrintElement( j );
        T = Insert( j, T );
    }
    printf("\n  InOrden: ");
    InOrder( T, PrintElement );
    printf("\n PreOrden: ");
    PreOrder( T, PrintElement );
    printf("\nPostOrden: ");
    PostOrder( T, PrintElement );
    printf("\n");

    return 0;
}

