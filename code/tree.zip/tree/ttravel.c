        #include "tree.h"
        #include <stdlib.h>
        #include "fatal.h"

        struct TreeNode
        {
            ElementType Element;
            SearchTree  Left;
            SearchTree  Right;
        };

void InOrder(SearchTree , void (*func)(ElementType ));
void PreOrder(SearchTree , void (*func)(ElementType ));
void PostOrder(SearchTree , void (*func)(ElementType ));

/* START: fig6_m1.txt */
void InOrder(SearchTree T , void (*func)(ElementType ))
{
   if(T->Left) InOrder(T->Left, func);
   func(T->Element);
   if(T->Right) InOrder(T->Right, func);
}
/* END */
 
/* Recorrido de �rbol en preorden, aplicamos la funci�n func, que tiene
   el prototipo:
   void func(int*);
*/

void PreOrder(SearchTree T, void (*func)(ElementType ))
{
   func(T->Element);
   if(T->Left) PreOrder(T->Left, func);
   if(T->Right) PreOrder(T->Right, func);
}
 
/* Recorrido de �rbol en postorden, aplicamos la funci�n func, que tiene
   el prototipo:
   void func(int*);
*/

void PostOrder(SearchTree T, void (*func)(ElementType ))
{
   if(T->Left) PostOrder(T->Left, func);
   if(T->Right) PostOrder(T->Right, func);
   func(T->Element);
}

